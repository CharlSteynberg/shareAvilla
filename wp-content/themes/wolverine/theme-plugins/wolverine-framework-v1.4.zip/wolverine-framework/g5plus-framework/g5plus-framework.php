<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
require_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'g5plus-framework/core/base.php' );
require_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'g5plus-framework/install-demo/install-demo.php' );
require_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'g5plus-framework/meta-box/meta-box.php' );
require_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'g5plus-framework/core/widget-custom-class.php' );
require_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'g5plus-framework/tax-meta-class/tax-meta-class.php' );